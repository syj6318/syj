from keras.utils import np_utils
import keras
from utilities import get_data, class_labels
#from read_data import get_data, class_labels
import tensorboard
import numpy
import matplotlib.pyplot as plt

dataset_path = 'speech_datasets'
#dataset_path = 'thchs-test'#128kbps，150%，rq8_16，50%，thchs
#dataset_path = 'dataset'
#dataset_path = '1280'
#dataset_path = 'thchs_train'
#dataset_path = 'thchs-test'

import tensorflow as tf
old_v = tf.logging.get_verbosity()
tf.logging.set_verbosity(tf.logging.ERROR)

#写一个LossHistory类，保存loss和acc
class LossHistory(keras.callbacks.Callback):
    def on_train_begin(self, logs={}):
        self.losses = {'batch':[], 'epoch':[]}
        self.accuracy = {'batch':[], 'epoch':[]}
        self.val_loss = {'batch':[], 'epoch':[]}
        self.val_acc = {'batch':[], 'epoch':[]}

    def on_batch_end(self, batch, logs={}):
        self.losses['batch'].append(logs.get('loss'))
        self.accuracy['batch'].append(logs.get('acc'))
        self.val_loss['batch'].append(logs.get('val_loss'))
        self.val_acc['batch'].append(logs.get('val_acc'))

    def on_epoch_end(self, batch, logs={}):
        self.losses['epoch'].append(logs.get('loss'))
        self.accuracy['epoch'].append(logs.get('acc'))
        self.val_loss['epoch'].append(logs.get('val_loss'))
        self.val_acc['epoch'].append(logs.get('val_acc'))

    def loss_plot(self, loss_type):
        iters = range(len(self.losses[loss_type]))
        plt.figure()
        # acc
        plt.plot(iters, self.accuracy[loss_type], 'r', label='train acc')
        # loss
        plt.plot(iters, self.losses[loss_type], 'g', label='train loss')
        if loss_type == 'epoch':
            # val_acc
            plt.plot(iters, self.val_acc[loss_type], 'b', label='val acc')
            # val_loss
            plt.plot(iters, self.val_loss[loss_type], 'k', label='val loss')
        plt.grid(linestyle='--', linewidth=1,alpha=0.5)
        plt.xlabel(loss_type)
        plt.ylabel('acc-loss')
        plt.legend()
        plt.show()

        #plt.savefig('G:/BaiduYunDownload/thchs-30/论文/论文一/论文/Log_Mel_Spectrogram/Log_Mel_Spectrogram.png')#####

def dnn_example():
    data, x_train, x_test, y_train, y_test = get_data(dataset_path=dataset_path, flatten=False)
    y_train = np_utils.to_categorical(y_train)
    y_test = np_utils.to_categorical(y_test)
    # in_shape = x_train[0].shape#398*15
    #
    # x_train = x_train.reshape(x_train.shape[0], in_shape[0], in_shape[1],1)#145,398,15,1
    #
    # x_test = x_test.reshape(x_test.shape[0], in_shape[0], in_shape[1],1)
    input_shape = x_train[0].shape

    from keras.models import Sequential, Model
    from keras.layers import Dense, Flatten, Dropout
    from keras.layers import LSTM as lstm, Dense, Dropout, Conv2D, Flatten, \
        BatchNormalization, Activation, MaxPooling2D
    from keras.layers.convolutional import Conv2D, MaxPooling2D
    from keras.layers.recurrent import SimpleRNN
    from keras.utils.np_utils import to_categorical
    import numpy as np
    import time

    seed = 7
    np.random.seed(seed)

    model = Sequential()

    #model.add(Conv2D(8, (7, 7),input_shape=(input_shape[0], input_shape[1], 1), activation='relu'))
    model.add(SimpleRNN(128,return_sequences=True,input_shape=(input_shape[0], input_shape[1])))#return_sequences=True,
    model.add(BatchNormalization(axis=-1))
    model.add(Dropout(0.75))
    #model.add(SimpleRNN(128,return_sequences=True))
    #model.add(BatchNormalization(axis=-1))
    #model.add(Dropout(0.5))
    model.add(Flatten())
    model.add(Dense(384, activation='relu', name="Dense_1"))
    #model.add(Dense(32, activation='relu'))
    model.add(Dense(10, activation='softmax'))
    model.compile(loss='binary_crossentropy', optimizer='SGD', metrics=['accuracy'])
    model.summary()
    start = time.clock()

    # 创建一个实列history
    history = LossHistory()

    model_out = model.fit(x_train, y_train,  batch_size=70, epochs=50,validation_data=(x_test, y_test),callbacks=[history])#,callbacks=[tensorboard(log_dir='./tmp/log')])

    dense1_layer_model = Model(inputs=model.input,
                               outputs=model.get_layer('Dense_1').output)

    end = time.clock()
    score = model.evaluate(x_test, y_test, batch_size=70)
    print(end-start)
    print(score)
    print('%s: %.2f%%' % (model.metrics_names[1], score[1] * 100))

    # 绘制acc-loss曲线
    history.loss_plot('epoch')
    #plt.savefig('G:/BaiduYunDownload/thchs-30/论文/论文一/论文/Log_Mel_Spectrogram/Log_Mel_Spectrogram.png')

    loss_history = model_out.history["loss"]
    numpy_loss_history = numpy.array(loss_history)
    numpy.savetxt("data/RNN/RNN_loss_history.txt", numpy_loss_history, delimiter="\n")

    acc_history = model_out.history["acc"]
    numpy_loss_history = numpy.array(acc_history)
    numpy.savetxt("data/RNN/RNN_acc_history.txt", numpy_loss_history, delimiter="\n")

    acc_history = model_out.history["val_loss"]
    numpy_loss_history = numpy.array(acc_history)
    numpy.savetxt("data/RNN/RNN_val_loss_history.txt", numpy_loss_history, delimiter="\n")

    acc_history = model_out.history["val_acc"]
    numpy_loss_history = numpy.array(acc_history)
    numpy.savetxt("data/RNN/RNN_val_acc_history.txt", numpy_loss_history, delimiter="\n")

    model.save('data/RNN/RNN.h5')

"""
    #from lshash.lshash import LSHash
    #t = 0
    out_list = []
    for i in range(0, len(data)):
        a = data[i].reshape(1,input_shape[0], input_shape[1], 1)
        b = dense1_layer_model.predict(a);t = np.mean(b); b[b<t]=0; b[b>=t]=1
        #lsh = LSHash(13, 64, num_hashtables=1)(b)
        out_list.append(b)

    import csv

    csvfile = "Model/dataset/2019.4.3/data13_1280audio_audio.csv"
    with open(csvfile, "w") as output:
        writer = csv.writer(output, lineterminator='\n')
        for val in out_list:
             writer.writerow(np.ndarray.tolist(val[0]))

    import matplotlib.pyplot as plt
    plt.title("Loss")
    plt.plot(model_out.history["loss"], color="r", label="train")
    plt.legend(loc="best")
    plt.tight_layout()
    plt.show()

    plt.title("Accuracy")
    plt.plot(model_out.history["acc"], color="r", label="train")
    plt.legend(loc="best")
    plt.tight_layout()
    plt.show()

    from sklearn.metrics import accuracy_score, precision_score, average_precision_score, recall_score, \
        classification_report, confusion_matrix

    y_pred_val, y_true_val = [], []
    for i in range(0, len(data)):
        a = data[i].reshape(1, input_shape[0], input_shape[1], 1)
        b = dense1_layer_model.predict(a); t = np.mean(b); b[b < t] = 0; b[b >= t] = 1
        y_pred_val.append(b)
        #y_true_val.append(data_sim_test[i][2])

    out_list = np.reshape(out_list, [-1])
    y_pred_val = np.reshape(y_pred_val, [-1])

    cm = confusion_matrix(y_pred_val, out_list)
    print(cm)

    pr = precision_score(y_pred_val, out_list)
    re = recall_score(y_pred_val, out_list)
    ap = average_precision_score(y_pred_val, out_list)
    print(pr, re, ap)
"""

if __name__ == "__main__":

    dnn_example()