function x=h_distance(h1,h2)
%��֪��ϣ����
[k1,len1]=size(h1);
[k2,len2]=size(h2);
sum=0;
if len1<=len2
    for i=1:len1
        sum=sum+abs(h1(i)-h2(i));
    end
    x=sum/len2;
else for i=1:len2
         sum=sum+abs(h1(i)-h2(i));
    end
    x=sum/len1;
end
