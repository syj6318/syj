from sklearn.metrics import accuracy_score, precision_score, average_precision_score, recall_score, \
        classification_report, confusion_matrix

import csv
from keras.models import Model
from get_data import get_data
import numpy as np
import pandas as pd
#dataset_path = '1280/1280audio'
dataset_path = 'thchs-test/GN'#128kbps，150%，rq8_16，50%，thchs，GN

def dnn_example():
    data,file = get_data(dataset_path=dataset_path, flatten=False)
    in_shape = data[0].shape
    #print(in_shape)
    data = data.reshape(data.shape[0], in_shape[0], in_shape[1], 1)
    #print(data.shape)
    input_shape = data[0].shape
    #print(input_shape)
    from keras.models import load_model
    model =load_model('D:/文档/论文三/程序/data/最终/CNN/log/CNN.h5')

    y_pred_val= []
    for i in range(0, len(data)):
        a = data[i].reshape(1,input_shape[0], input_shape[1], 1)
        dense1_layer_model = Model(inputs=model.input,
                                   outputs=model.get_layer('Dense_1').output)#dese_1#Dense_1

        b = dense1_layer_model.predict(a);t = np.median(b); b[b<=t]=0; b[b>t]=1
        y_pred_val.append(b)
        #y_true_val.append(data_sim_test[i][2])
    csv_file = 'D:/文档/论文三/程序/data/最终/CNN/log/LOG_CNN_thchs.csv'
    y_true_val = pd.read_csv(csv_file, header=None, engine='python')
    y_true_val = y_true_val.values.tolist()
    y_true_val = np.reshape(y_true_val, [-1])
    y_pred_val = np.reshape(y_pred_val, [-1])

    cm = confusion_matrix(y_pred_val, y_true_val)
    print(cm)

    pr = precision_score(y_pred_val, y_true_val)
    re = recall_score(y_pred_val, y_true_val)
    ap = average_precision_score(y_pred_val, y_true_val)
    print(ap)

if __name__ == "__main__":

    dnn_example()