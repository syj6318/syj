from keras.models import Model
from get_data import get_data
import numpy as np
#dataset_path = '1280/1280audio'
dataset_path = 'thchs-test/thchs'#128kbps，150%，rq8_16，50%，thchs，GN


def dnn_example():
    data,file = get_data(dataset_path=dataset_path, flatten=False)

    in_shape = data[0].shape
    #print(in_shape)
    data = data.reshape(data.shape[0], in_shape[0], in_shape[1], 1)
    #print(data.shape)


    input_shape = data[0].shape
    #print(input_shape)+

    from keras.models import load_model
    model =load_model('D:/文档/论文三/程序/data/CNN+LSTM/MFCC/relu/important/9/CNN.h5')


    out_list = []
    for i in range(0, len(data)):
        a = data[i].reshape(1,input_shape[0], input_shape[1], 1)
        #print(a.shape)
        c = file[i]
        dense1_layer_model = Model(inputs=model.input,
                                   outputs=model.get_layer('Dense_1').output)#dese_1#Dense_1

        b = dense1_layer_model.predict(a);t = np.median(b); b[b<=t]=0; b[b>t]=1
        # 将数据使用正太分布标准化，减去均值然后再除以方差
        #b = (b - np.mean(b)) // np.std(b)
        out_list.append(b)

    import csv

    csvfile = "D:/文档/论文三/程序/data/CNN+LSTM/MFCC/relu/important/9/MFCC_CNN_thchs.csv"
    #csvfile = "Model/speech_datasets/2019.4.16/speech_data11_thchs_audio.csv"
    #csvfile = "Model/speech_datasets/4.18/speech_data11.2_1280audio_audio.csv"
    with open(csvfile, "w") as output:
        writer = csv.writer(output, lineterminator='\n')
        for val in out_list:
            writer.writerow(np.ndarray.tolist(val[0]))
    print("Finish !")

if __name__ == "__main__":

    dnn_example()