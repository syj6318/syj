clc;clear;
syms x s
% load('audio1280.mat');
% x=K;
 s = int(exp((-(x-0.4688)^2)./(2*(0.0356^2))),x,-inf,0.16);
% s = int(exp((-(x-0.4922)^2)./(2*(0.033^2))));trapz
 a = s./(sqrt(2*pi)*0.0356);
 double (a)
 