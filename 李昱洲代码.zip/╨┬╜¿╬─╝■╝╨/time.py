from keras.models import Model
from get_data import get_data
import numpy as np
import time

dataset_path = 'D:/文档/10000'
#dataset_path = 'thchs-test/thchs'#128kbps，150%，rq8_16，50%，thchs，GN

import tensorflow as tf
old_v = tf.logging.get_verbosity()
tf.logging.set_verbosity(tf.logging.ERROR)

def dnn_example():
    start = time.clock()
    data, file = get_data(dataset_path=dataset_path, flatten=False)

    in_shape = data[0].shape
    # print(in_shape)
    data = data.reshape(data.shape[0], in_shape[0], in_shape[1], 1)
    # print(data.shape)

    input_shape = data[0].shape
    # print(input_shape)+

    from keras.models import load_model
    model = load_model('data/BLSTM/blstm_MFCC_10.h5')

    out_list = []
    for i in range(0, len(data)):
        a = data[i].reshape(1, input_shape[0], input_shape[1], 1)
        # print(a.shape)
        c = file[i]
        dense1_layer_model = Model(inputs=model.input,
                                   outputs=model.get_layer('Dense_1').output)  # dese_1#Dense_1

        b = dense1_layer_model.predict(a);t = np.median(b);b[b <= t] = 0;b[b > t] = 1
        # 将数据使用正太分布标准化，减去均值然后再除以方差
        # b = (b - np.mean(b)) // np.std(b)
        out_list.append(b)

    end = time.clock()

    print(end - start)
    import csv
    csvfile = "data/BLSTM/blstm_MFCC_10.csv"
    #csvfile = "D:/文档/论文二/程序/data/LSTM/MFCC/2019.5.18/11/LSTM_GN_median.csv"
    with open(csvfile, "w") as output:
        writer = csv.writer(output, lineterminator='\n')
        for val in out_list:
            writer.writerow(np.ndarray.tolist(val[0]))
    print("Finish !")

if __name__ == "__main__":

    dnn_example()