import os
import numpy as np
import pandas as pd
import time
import math
import tensorflow as tf
from keras import Model
from keras.models import Sequential
import keras.backend as K
from keras.layers import *
from keras.models import load_model
from keras.utils import plot_model, to_categorical
from keras import regularizers
from keras.constraints import non_neg
from keras.initializers import RandomUniform, RandomNormal
from matplotlib import pyplot as plt


# In[*]
def generate_data(datasize, feature_cnt, feature_key, feature_min, feature_max, data_split):
    np.random.seed(1327)  # 有预见的随机，方便调试

    data_split = int(datasize * data_split)

    data = np.random.randint(low=feature_min, high=feature_max + 1, size=(datasize, feature_cnt))  # 值在[low,high)
    # print(data)

    label = data[:, feature_key - 1].reshape(len(data), 1)  # 让标签与数据的某一维特征相同。 feature_key<=feature_cnt
    # print(label)
    label = [to_categorical(lab[0], feature_max + 1) for lab in label]  # 将标签由数值转化为one-hot形式，用于多分类
    label = np.array(label)

    # print(label)

    train_x = data[:data_split]
    train_y = label[:data_split]
    test_x = data[data_split:]
    test_y = label[data_split:]

    '''
    print('-------------train datasize:',len(train_x))
    print('train_x:\n',train_x)
    print('train_y:\n',train_y)
    print()
    print('-------------test datasize:',len(test_x))
    print('test_x:\n',test_x)
    print('test_y:\n',test_y)
    '''
    return train_x, train_y, test_x, test_y




# In[*]
def build_model(feature_cnt, feature_max, model_type, merge_type, dim):
    K.clear_session()  # 清除之前的模型，省得压满内存
    inputs = Input(shape=(feature_cnt,), dtype='int32')

    embd = Embedding(feature_max + 1, dim)(inputs)
    embd = BatchNormalization()(embd)
    Dropout(0.25)
    if model_type != 'basic':
        if model_type == 'att1':
            hidden = attention_block_1(embd, feature_cnt, dim)
        elif model_type == 'att2':
            hidden = attention_block_2(embd, feature_cnt, dim)
        elif model_type == 'att3':
            hidden = attention_block_3(embd, feature_cnt, dim)

        if merge_type == 'avg':
            # hidden = GlobalAveragePooling1D()(hidden)
            hidden = Lambda(lambda x: K.mean(x, axis=1))(hidden)
        else:
            hidden = Flatten()(hidden)
    else:
        hidden = Flatten()(embd)
    outputs = Dense(feature_max + 1, activation='softmax')(hidden)
    model = Model(inputs=inputs, outputs=outputs)
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    model.summary()
    return model


# In[*]
def attention_block_1(inputs, feature_cnt, dim):
    h_block = int(feature_cnt * dim / 32 / 2)
    hidden = Flatten()(inputs)
    while (h_block >= 1):
        h_dim = h_block * 32
        hidden = Dense(h_dim, activation='selu', use_bias=True)(hidden)
        h_block = int(h_block / 2)
    attention = Dense(feature_cnt, activation='softmax', name='attention')(hidden)
    attention = RepeatVector(dim)(attention)
    attention = Permute((2, 1))(attention)

    attention_out = Multiply()([attention, inputs])
    return attention_out


# In[*]
def attention_block_2(inputs, feature_cnt, dim):
    a = Permute((2, 1))(inputs)
    a = Reshape((dim, feature_cnt))(a)  # this line is not useful. It's just to know which dimension is what.
    a = Dense(feature_cnt, activation='softmax')(a)
    a = Lambda(lambda x: K.mean(x, axis=1), name='attention')(a)
    a = RepeatVector(dim)(a)
    a_probs = Permute((2, 1), name='attention_vec')(a)
    attention_out = Multiply()([inputs, a_probs])
    return attention_out


# In[*]
def attention_block_3(inputs, feature_cnt, dim):
    a = Flatten()(inputs)
    a = Dense(feature_cnt * dim, activation='softmax')(a)
    a = Reshape((feature_cnt, dim,))(a)
    a = Lambda(lambda x: K.sum(x, axis=2), name='attention')(a)
    a = RepeatVector(dim)(a)
    a_probs = Permute((2, 1), name='attention_vec')(a)
    attention_out = Multiply()([inputs, a_probs])
    return attention_out


# In[*]
def train(train_x, train_y, test_x, test_y, feature_cnt, feature_max, model_type, epochs, merge_type, dim):
    model = build_model(feature_cnt, feature_max, model_type, merge_type, dim)
    model.fit(train_x, train_y
              , batch_size=64
              , epochs=epochs
              , validation_data=(test_x, test_y)
              # ,validation_split=0.1
              )
    if model_type != 'basic':
        att = get_layer_output(model, 'attention', test_x)
        print(att)
        plt.bar(np.arange(feature_cnt), att)
        print(np.sum(att))


# In[*]
def get_layer_output(model, layer_name, inputs):
    layer = Model(inputs=model.input,
                  outputs=model.get_layer(layer_name).output)
    layer_out = layer.predict(inputs)
    #    print(layer_out[0])
    return np.mean(layer_out, axis=0)


# In[*]
datasize = 10000  # 数据规模
feature_cnt = 12  # 特征数量
feature_key = 3  # 人为设得的重要特征，期望注意力机制能正确捕捉到。feature_key<=feature_cnt

feature_range = 1000  # 特征的值域
feature_min = 0  # 特征最小值
feature_max = feature_range - 1  # 特征最大值

data_split = 0.8  # 数据集划分比例
epochs = 10  # 训练轮数
dim = 32  # 嵌入维度


train_x, train_y, test_x, test_y = generate_data(datasize, feature_cnt, feature_key,
                                                 feature_min, feature_max, data_split)

print('x_train shape:', train_x.shape)
print('x_test shape:', test_x.shape)

model_types = ['basic', 'att1', 'att2', 'att3']
model_type = model_types[1]
merge_types = ['avg', 'concat']
merge_type = merge_types[0]
train(train_x, train_y, test_x, test_y, feature_cnt, feature_max, model_type, epochs, merge_type, dim)