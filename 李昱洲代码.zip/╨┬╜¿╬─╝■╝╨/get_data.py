import numpy as np

import scipy.io.wavfile as wav
import os

from feature_extractor import cochleagram_extractor
import ctypes

mslen = 160000

import librosa
# load wavefile, set settings for that
def get_samps(wavefile, sr=None, high_quality=None):
    if sr is None:
        sr = 16000
    if high_quality:
        quality = "kaiser_high"
    else:
        quality = "kaiser_fast"
    y, sr = librosa.load(wavefile, sr=sr, res_type=quality)

    return y, sr

def gfcc_extractor(cochleagram, gf_channel, cc_channels):
    dctcoef = np.zeros((cc_channels, gf_channel))
    for i in range(cc_channels):
        n = np.linspace(0, gf_channel-1, gf_channel)
        dctcoef[i, :] = np.cos((2 * n + 1) * i * np.pi / (2 * gf_channel))

    return np.matmul(dctcoef, cochleagram)

def read_sphere_wav(file_name):
    wav_file = open(file_name, 'rb')
    #raw_header = wav_file.read(1024).decode('utf-8')
    raw_data = wav_file.read()
    wav_file.close()
    sample_count = len(raw_data) // 2

    wav_data = np.zeros(shape=[sample_count], dtype=np.int32)

    for i in range(sample_count):
        #wav_data[i] = ctypes.c_int16(ord(raw_data[2 * i + 1]) << 8).value + ctypes.c_int16(ord(raw_data[2 * i])).value
        wav_data[i] = ctypes.c_int16(raw_data[2 * i + 1] << 8).value + ctypes.c_int16(raw_data[2 * i]).value

    #header_list = raw_header.split("\n")
    #sphere_header = {}
    # for s in header_list:
    #     if len(s) > 0 and s != "end_head":
    #         tmp = s.split(" ")
    #         if 0 < len(tmp) < 3:
    #             sphere_header['Name'] = tmp[0]
    #         elif len(tmp[0]) > 0:
    #             sphere_header[tmp[0]] = tmp[2]

    return wav_data#, sphere_header

def get_gfcc(y, sr, num_gfcc=None, window_size=None, window_shift=None):
    '''
    set values: default for GFCCs extraction:
    - 40 GFCCs
    - windows of 25ms
    - window shifts of 10ms
    '''
    if num_gfcc is None:
        num_gfcc = 40
    if window_size is None:
        n_fft = int(0.025 * sr)
    else:
        n_fft = int(window_size * 0.001 * sr)
    if window_shift is None:
        hop_length = int(0.010 * sr)
    else:
        hop_length = int(window_shift * 0.001 * sr)
    cochlea = cochleagram_extractor(y, sr, n_fft, hop_length, 64, 'hanning')
    gfccs = gfcc_extractor(cochlea, 64, num_gfcc)
    gfccs = np.transpose(gfccs)
    gfccs -= (np.mean(gfccs, axis=0) + 1e-8)

    return gfccs

# set settings for mfcc extraction
def get_mfcc(y, sr, num_mfcc=None, window_size=None, window_shift=None):
    '''
    set values: default for MFCCs extraction:
    - 40 MFCCs
    - windows of 25ms
    - window shifts of 10ms
    '''
    if num_mfcc is None:
        num_mfcc = 40
    if window_size is None:
        n_fft = int(0.025 * sr)
    else:
        n_fft = int(window_size * 0.001 * sr)
    if window_shift is None:
        hop_length = int(0.010 * sr)
    else:
        hop_length = int(window_shift * 0.001 * sr)
    mfccs = librosa.feature.mfcc(y, sr, n_mfcc=num_mfcc, hop_length=hop_length, n_fft=n_fft)
    mfccs = np.transpose(mfccs)
    mfccs -= (np.mean(mfccs, axis=0) + 1e-8)

    return mfccs


# get fbank, and set settings for that
def get_mel_spectrogram(y, sr, num_mels=None, window_size=None, window_shift=None):
    '''
    set values: default for mel spectrogram calculation (FBANK)
    - windows of 25ms
    - window shifts of 10ms
    '''
    if num_mels is None:
        num_mels = 40
    if window_size is None:
        n_fft = int(0.025 * sr)
    else:
        n_fft = int(window_size * 0.001 * sr)
    if window_shift is None:
        hop_length = int(0.010 * sr)
    else:
        hop_length = int(window_shift * 0.001 * sr)

    fbank = librosa.feature.melspectrogram(y, sr, n_fft=n_fft, hop_length=hop_length, n_mels=num_mels)

    # convert to log scale
    #fbank = librosa.power_to_db(fbank)

    fbank = np.transpose(fbank)
    fbank -= (np.mean(fbank, axis=0) + 1e-8)

    return fbank


def read_wav(filename):

    return wav.read(filename)


def get_data(dataset_path, flatten=True, mfcc_len=20):

    data = []
    file = []
    max_fs = 0
    min_sample = int('9' * 10)

    cnt = 0
    cur_dir = os.getcwd()

    os.chdir(dataset_path)

    for filename in os.listdir('.'):

        #fs, signal = read_wav(filename)
        signal, fs = get_samps(filename)#MFCC
        #signal = read_sphere_wav(filename)  # GFCC
        fs = 16000
        max_fs = max(max_fs, fs)
        s_len = len(signal)

        if s_len < mslen:
            pad_len = mslen - s_len
            pad_rem = pad_len % 2
            pad_len //= 2
            signal = np.pad(signal, (pad_len, pad_len + pad_rem), 'constant', constant_values=0)
        else:
            pad_len = s_len - mslen
            pad_len //= 2
            signal = signal[pad_len:pad_len + mslen]
        min_sample = min(len(signal), min_sample)
        #mfcc = speechpy.feature.mfcc(signal, fs, num_cepstral=mfcc_len)
        #mfcc = get_mfcc(signal, fs, num_mfcc=mfcc_len, window_size=25, window_shift=10)#librosa mfcc
        #mfcc = get_gfcc(signal, fs, num_gfcc=mfcc_len, window_size=25, window_shift=10)  # GFCC
        mfcc = get_mel_spectrogram(signal, fs, num_mels=mfcc_len)  # fbank/log mel
        #mfcc = mfcc[::2]  #  每隔一行进行一次取样
        #print(mfcc.shape)
        if flatten:

            mfcc = mfcc.flatten()
        data.append(mfcc)
        file.append(filename)
        #data.append(abs(mfcc))

        cnt += 1

    os.chdir('..')
    os.chdir(cur_dir)
    # 将数据使用正太分布标准化，减去均值然后再除以方差
    #data = (data - np.mean(data)) // np.std(data)



    return np.array(data),np.array(file)


